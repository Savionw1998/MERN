import React, {useState} from "react";
import UserForm from './components/UserForm';
import UserInfo from './components/UserInfo';

function App() {
  const [state, setState] = useState({
    firstName: "",
    lastname: "",
    email: "",
    password: "",
    passwordconfirmation: "",
  });

  return (
    <div className="App">
      <UserForm inputs={state} setInputs={setState}/>
      <UserInfo data={state}/>

    </div>
  );
}

export default App;
