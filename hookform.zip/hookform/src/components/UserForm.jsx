import React, { useState } from  'react';

const UserForm = (props) => {
        const [inputs, setInputs] = useState("");
        const [ error1, setNameErrors] = useState("");
        const [ error2, setPasswordErrors] = useState("");
        const [ error3, setEmailErrors] = useState("");

        const onChange = e => {
            setInputs({
                ...inputs,
                [e.target.name]: e.target.value
            });
        };

        const handleNameErrors = (e) => {
            setInputs(e.target.value);
            if(e.target.value.length < 1) {
                setNameErrors("is required!");
            } else if(e.target.value.length < 3) {
                setNameErrors("must be 3 characters or longer!");
            } else {
                setNameErrors("");
            }
        }
        const handlePasswordErrors = (e) => {
            setInputs(e.target.value);
            if(e.target.value.length < 1) {
                setPasswordErrors("is required!");
            } else if(e.target.value.length < 3) {
                setPasswordErrors("must be 3 characters or longer!");
            } else {
                setNameErrors("");
            }
        }
        const handleEmailErrors = (e) => {
            setInputs(e.target.value);
            if(e.target.value.length < 1) {
                setEmailErrors("is required!");
            } else if(e.target.value.length < 3) {
                setEmailErrors("must be 3 characters or longer!");
            } else {
                setNameErrors("");
            }
        }

    return(
        <form>
            <div className="formgroup">
                <label htmlFor="firstName">First name: </label> 
                <input onChange={handleNameErrors} type="text" name="firstName" />
                {
                    error1 ?
                    <p style={{color:'red'}}>{ error1 }</p> :
                    ''
                }
            </div>
            <div className="formgroup">
                <label htmlFor="lastName">Last Name: </label> 
                <input onChange={onChange} type="text" name="lastName" />
                {
                    error1 ?
                    <p style={{color:'red'}}>{ error1 }</p> :
                    ''
                }
            </div>
            <div className="formgroup">
                <label htmlFor="email">Email: </label> 
                <input onChange={handleEmailErrors} type="text" name="email" />
                {
                    error3 ?
                    <p style={{color:'red'}}>{ error3 }</p> :
                    ''
                }
            </div>
            <div className="formgroup">
                <label htmlFor="password">Password: </label> 
                <input onChange={handlePasswordErrors} type="password" name="password" />
                {
                    error2 ?
                    <p style={{color:'red'}}>{ error2 }</p> :
                    ''
                }
            </div>
            <div className="formgroup">
                <label htmlFor="passwordConfirmation">Password Confirmation: </label> 
                <input onChange={handlePasswordErrors} type="password" name="passwordConfirmation" />
                {
                    error2 ?
                    <p style={{color:'red'}}>{ error1 }</p> :
                    ''
                }
            </div>
        </form>
    );
};
    
export default UserForm;