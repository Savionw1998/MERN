import React from  'react';

const UserInfo = props => {
    const {firstName, lastName, email, password, passwordConfirmation} = props.data;

    return (
        <div>
            <h1>Results</h1>
            <h4>First Name: {firstName}</h4>
            <h4>Last Name: {lastName}</h4>
            <h4>Email: {email}</h4>
            <h4>Password: {password}</h4>
            <h4>Password Confirmation: {passwordConfirmation}</h4>
        </div>
    );
};
export default UserInfo;
