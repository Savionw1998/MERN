import React, { useState } from 'react';

const New = ({createBox}) => {
    const [color, setColor] = useState();

    const submitColor = (e) => {
        e.preventDefault();
        createBox({color: color});
        setColor("");
        // const newBox = { color };
        // setHasBeenSubmitted( true );
    };

    return (
        <div>
            <>
                What the user is typing : {color}
                <br/>
                <form onSubmit={submitColor}>
                    <br/>
                    <input type="color" value={color} onChange={ (e) => setColor(e.target.value)}/>
                    <br/>
                    <input type="submit" value={"Add Color!"}/>
                    <br/>
                </form>
            </>
        </div>

    );
};
export default New