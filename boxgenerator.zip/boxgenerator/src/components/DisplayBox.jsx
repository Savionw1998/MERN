import React, { useState } from  'react';

const DisplayBox = ({boxes}) => {

    return(
        <div classname="container">
            {boxes.map((box, i) => {return(
                <div key={i} style={{backgroundColor: box.color, 
                                    width:'200px', 
                                    height:'200px', 
                                    display:'inline-block', 
                                    verticleAlign:'top'}} classname="box"/>)
        })}
        </div>

    );
}
export default DisplayBox;