import './App.css';
import React, {useState} from "react";
import DisplayBox from './components/DisplayBox';
import New from './components/New';



function App() {
  const [boxes, setBoxes] = useState([
    {color: "Blue"},
    {color: "Red"},
    {color: "Green"},
    {color: "Yellow"}
  ])

  const createBox = (box) => {
    setBoxes([...boxes, box])
  };

  // const deleteBox = (deleteIdx) => {
  //   setBoxes(boxes.filter((box, i) => i !== deleteIdx ? true : false));
  // }

  // const updateBox = (idx) => {
  //   const copyBoxes = [...boxes];
  //   copyBoxes[idx].status = !copyBoxes[idx].status;
  //   setBoxes(copyBoxes);
  // }

  return (
    <div className="App">
      <New createBox={createBox}/>
      <DisplayBox boxes={boxes}/>
    </div>
  );
}

export default App;
