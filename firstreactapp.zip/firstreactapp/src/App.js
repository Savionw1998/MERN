import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
<h1>Hello Dojo</h1>
<h2>Things to do:</h2>
<ol>
  <li>Sweep</li>
  <li>Mop</li>
  <li>Dry</li>
  <li>Cry</li>
</ol>
    </div>
  );
}

export default App;
