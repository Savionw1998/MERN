import {useState} from 'react';
import './App.css';
import { Router, navigate } from '@reach/router';
import Home from './components/Home'


function App() {

  const [type, setType] = useState("");
  const [id, setId] = useState("");


  const submitHandler = (e) => {
    e.preventDefault();
    navigate(`/${type}/${id}`);
  }

  return (
    <div className="App">
      <form onSubmit = {submitHandler}>
        <input type="text" value = {type} onChange = {(e) => {setType(e.target.value)}}/>
        <input type="text" value = {id} onChange = {(e) => {setId(e.target.value)}}/>
        <button type = "submit"> Grab Item </button>

      </form>
      <Router>
      <Home path="/:type/:id" />
      </Router>
    </div>
  );
}

export default App;
