const express = require("express");
const faker = require("faker");
const app = express();

class Fake{
  constructor(){
    this.name = `${faker.name.title()}`;
    this.phrase = faker.hacker.phrase();
    this.address = faker.phone.phoneNumber();
    this.company = faker.company.catchPhrase();
    this.title = faker.name.jobTitle();
  }
};

app.use(express.json());

app.get("/user/new", (req, res) => {
  res.json(new Fake());
});

const server = app.listen(8000, () =>
  console.log(`Server is locked and loaded on port ${server.address().port}!`)
);


