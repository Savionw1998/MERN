const Joke = require('../models/Jokes.models');

module.exports.findAllJokes = (req, res) => {
    Joke.find()
        .then(allDaJokes => res.json({ jokes: allDaJokes }))
        .catch(err => res.json({message: 'No Jokes BOII!!!', errors: err}));
}
module.exports.findOneJokes = (req, res) => {
    Joke.findOne({ __id: req.params.id })
        .then(OneJoke => res.json({ jokes: OneJoke }))
        .catch(err => res.json({message: 'No Joke BOII!!!', errors: err}));
}
module.exports.newJoke = (req, res) => {
    Joke.create(req.body)
        .then(createdJoke => res.json({ jokes: createdJoke }))
        .catch(err => res.json({message: 'No Joke BOII!!!', errors: err}));
}
module.exports.updateJoke = (req, res) => {
    Joke.updateOneJoke(
        { __id: req.params.id} , 
        req.body,
        { new: true, runValidators: true }
        )
        .then(OneJoke => res.json({ jokes: OneJoke }))
        .catch(err => res.json({message: 'No BOII!!!', errors: err}));
}
module.exports.deleteJoke = (req, res) => {
    Joke.deleteOneJoke({ __id: req.params.id })
        .then(result => (res.json({ result: result })))
        .catch(err => res.json({ message: 'Noooooooo', errors: err }));
}