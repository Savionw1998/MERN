const JokesController = require('../controllers/Jokes.controller');

module.exports = app => {
    app.get('/', JokesController.findAllJokes);
    app.get('/:id', JokesController.findOneJokes);
    app.put('/:id', JokesController.updateJoke);
    app.post('/new', JokesController.newJoke);
    app.delete('/:id', JokesController.deleteJoke);
}